<template>
  <div class="w-full">
    <div class="w-full rounded-xl border border-[#555] p-6">
      <!-- Название задачи -->
      <div class="mb-8">
        <label class="block mb-2 text-gray-400"> Название задачи </label>

        <input
          v-model="form.title"
          placeholder="Например: Добавить атрибут Назначение для беговой обуви"
          class="w-full py-3 px-4 rounded-md border border-[#555] bg-transparent outline-none text-white placeholder:text-gray-600"
        />
      </div>

      <!-- Тип задачи -->
      <div class="mb-8">
        <label class="block mb-3 text-gray-400"> Тип задачи </label>

        <div class="flex flex-wrap gap-3">
          <button
            v-for="type in types"
            :key="type.value"
            @click="toggleType(type.value)"
            :class="[
              'px-5 py-3 rounded-lg border transition flex items-center gap-2',

              form.types.includes(type.value)
                ? 'bg-blue-600 border-blue-600 text-white'
                : 'border-[#555] text-gray-300 hover:bg-[#181818]',
            ]"
          >
            <span
              class="w-2 h-2 rounded-full"
              :class="
                form.types.includes(type.value) ? 'bg-white' : 'bg-gray-500'
              "
            />

            {{ type.label }}
          </button>
        </div>
      </div>

      <!-- Дополнительный контекст -->
      <div class="mb-8">
        <label class="block mb-3 text-gray-400"> Контекст </label>

        <div class="grid grid-cols-2 gap-5">
          <!-- Категория -->
          <input
            v-model="form.category"
            placeholder="Категория (например: Горные лыжи)"
            class="w-full py-3 px-4 rounded-md border border-[#555] bg-transparent outline-none text-white placeholder:text-gray-600"
          />

          <!-- Бренд -->
          <input
            v-model="form.brand"
            placeholder="Бренд (например: Rossignol)"
            class="w-full py-3 px-4 rounded-md border border-[#555] bg-transparent outline-none text-white placeholder:text-gray-600"
          />
        </div>
      </div>

      <!-- Приоритет + дедлайн -->
      <div class="grid grid-cols-2 gap-5 mb-8">
        <!-- Приоритет -->
        <div>
          <label class="block mb-2 text-gray-400"> Приоритет </label>

          <select
            v-model="form.priority"
            class="w-full py-3 px-4 rounded-md border border-[#555] bg-[#121212] text-white outline-none"
          >
            <option value="high">Высокий</option>

            <option value="medium">Средний</option>

            <option value="low">Низкий</option>
          </select>
        </div>

        <!-- Дедлайн -->
        <div>
          <label class="block mb-2 text-gray-400"> Дедлайн </label>

          <input
            v-model="form.deadline"
            type="date"
            class="w-full py-3 px-4 rounded-md border border-[#555] bg-transparent text-white outline-none"
          />
        </div>
      </div>

      <!-- Описание задачи -->
      <div class="mb-8">
        <label class="block mb-2 text-gray-400"> Описание задачи </label>

        <textarea
          v-model="form.description"
          placeholder="
Например:
Создать новый атрибут Назначение,
добавить его товарам категории Кроссовки,
создать посадочную страницу.
          "
          class="w-full h-40 resize-none py-3 px-4 rounded-md border border-[#555] bg-transparent outline-none text-white placeholder:text-gray-600"
        />
      </div>

      <!-- Кнопка -->

      <button
        @click="createTask"
        class="px-8 py-3 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700 transition"
      >
        Создать задачу
      </button>
    </div>
  </div>
</template>

<script setup>
import { reactive } from 'vue'

const types = [
  {
    label: 'Атрибуты',
    value: 'attribute',
  },

  {
    label: 'Карточки',
    value: 'product',
  },

  {
    label: 'Описание',
    value: 'description',
  },

  {
    label: 'Страницы',
    value: 'page',
  },
]

const form = reactive({
  title: '',

  types: [],

  category: '',

  brand: '',

  priority: 'medium',

  deadline: '',

  description: '',
})

const toggleType = (type) => {
  const index = form.types.indexOf(type)

  if (index === -1) {
    form.types.push(type)
  } else {
    form.types.splice(index, 1)
  }
}

const createTask = () => {
  console.log({
    ...form,
  })
}
</script>
