<template>
  <section class="flex flex-col p-6 w-full h-full text-white">
    <!-- Заголовок -->
    <div class="mb-10">
      <h1 class="text-2xl font-bold">Создание задачи</h1>

      <p class="text-gray-400 mt-2">
        Создайте задачу, а действия добавляйте уже внутри неё
      </p>
    </div>

    <TaskForm />
  </section>
</template>

<script setup>
import TaskForm from '@/tasks/TaskForm.vue'
</script>
